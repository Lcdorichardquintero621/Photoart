package com.fotoestilo.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

fun loadScaled(ctx: Context, uri: Uri, maxSide: Int): Bitmap {
    val src = ImageDecoder.createSource(ctx.contentResolver, uri)
    return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val m = maxOf(info.size.width, info.size.height)
        if (m > maxSide) {
            val s = maxSide.toFloat() / m
            decoder.setTargetSize((info.size.width * s).toInt(), (info.size.height * s).toInt())
        }
    }
}

fun saveToGallery(ctx: Context, bmp: Bitmap) {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "PhotoArt_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PhotoArt")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
    if (uri != null) {
        ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        Toast.makeText(ctx, "Guardada en Galería", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    var serverUrl by remember { mutableStateOf(prefs.getString("url", "http://192.168.1.10:8000") ?: "") }
    var apiKey by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var source by remember { mutableStateOf<Bitmap?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var showResult by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var seed by remember { mutableLongStateOf(42L) }

    val pager = rememberPagerState { TEMPLATES.size }
    val template = TEMPLATES[pager.currentPage]
    var strength by remember(template.id) { mutableFloatStateOf(template.strength) }
    var control by remember(template.id) { mutableFloatStateOf(template.control) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            source = loadScaled(ctx, uri, 1024)
            result = null
            error = null
        }
    }

    fun generate(newSeed: Boolean) {
        val src = source ?: return
        if (newSeed) seed = Random.nextLong(0, 1_000_000)
        prefs.edit().putString("url", serverUrl).putString("key", apiKey).apply()
        busy = true
        error = null
        scope.launch {
            try {
                val bmp = withContext(Dispatchers.IO) {
                    val out = ByteArrayOutputStream()
                    src.compress(Bitmap.CompressFormat.JPEG, 92, out)
                    ApiClient.stylize(serverUrl, apiKey, out.toByteArray(), template, strength, control, seed)
                }
                result = bmp
                showResult = true
            } catch (e: Exception) {
                error = e.message ?: "Error desconocido"
            }
            busy = false
        }
    }

    fun enhance(scale: Int) {
        val base = result ?: source ?: return
        if (maxOf(base.width, base.height) > 2048) {
            error = "La imagen ya está en alta resolución"
            return
        }
        prefs.edit().putString("url", serverUrl).putString("key", apiKey).apply()
        busy = true
        error = null
        scope.launch {
            try {
                val bmp = withContext(Dispatchers.IO) {
                    val out = ByteArrayOutputStream()
                    base.compress(Bitmap.CompressFormat.JPEG, 95, out)
                    ApiClient.upscale(serverUrl, apiKey, out.toByteArray(), scale)
                }
                result = bmp
                showResult = true
            } catch (e: Exception) {
                error = e.message ?: "Error desconocido"
            }
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Image(
                painter = painterResource(R.drawable.photoart_logo),
                contentDescription = "PhotoArt",
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp))
            )
            Text("PhotoArt", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }

        // Carrusel de plantillas
        HorizontalPager(
            state = pager,
            contentPadding = PaddingValues(horizontal = 56.dp),
            pageSpacing = 12.dp
        ) { page ->
            val t = TEMPLATES[page]
            Box(
                Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(t.c1, t.c2))),
                contentAlignment = Alignment.BottomStart
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(t.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(t.desc, fontSize = 14.sp, color = Color.White)
                }
            }
        }

        Button(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()
        ) { Text("Elegir foto") }

        // Vista previa
        val shown = if (showResult && result != null) result else source
        if (shown != null) {
            Image(
                bitmap = shown.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp))
            )
            if (result != null) {
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !showResult, onClick = { showResult = false }, label = { Text("Original") })
                    FilterChip(selected = showResult, onClick = { showResult = true }, label = { Text("Resultado") })
                }
            }
        }

        shown?.let {
            Text(
                "${it.width} × ${it.height} px",
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        // Ajustes
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text("Intensidad del estilo: ${(strength * 100).toInt()}%")
            Slider(value = strength, onValueChange = { strength = it }, valueRange = 0.25f..0.9f)
            Text("Fidelidad a la foto: ${(control * 100).toInt()}%")
            Slider(value = control, onValueChange = { control = it }, valueRange = 0.3f..1.2f)
        }

        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { generate(false) }, enabled = source != null && !busy, modifier = Modifier.weight(1f)) {
                Text("Generar")
            }
            OutlinedButton(onClick = { generate(true) }, enabled = source != null && !busy, modifier = Modifier.weight(1f)) {
                Text("Regenerar")
            }
        }
        Text("Mejorar calidad y ampliar", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { enhance(2) }, enabled = source != null && !busy, modifier = Modifier.weight(1f)) {
                Text("Mejorar 2x")
            }
            OutlinedButton(onClick = { enhance(4) }, enabled = source != null && !busy, modifier = Modifier.weight(1f)) {
                Text("Ampliar 4x")
            }
        }
        if (busy) LinearProgressIndicator(Modifier.padding(horizontal = 16.dp).fillMaxWidth())
        error?.let { Text(it, color = Color(0xFFFF8A80), modifier = Modifier.padding(horizontal = 16.dp)) }

        result?.let {
            OutlinedButton(
                onClick = { saveToGallery(ctx, it) },
                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth()
            ) { Text("Guardar en Galería") }
        }

        // Servidor
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Servidor", fontWeight = FontWeight.Bold)
            OutlinedTextField(serverUrl, { serverUrl = it }, label = { Text("URL (http://IP:8000)") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API key") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
        }
    }
}
