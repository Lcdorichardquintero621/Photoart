package com.fotoestilo.app

import androidx.compose.ui.graphics.Color

data class Template(
    val id: String,
    val name: String,
    val desc: String,
    val c1: Color,
    val c2: Color,
    val prompt: String,
    val strength: Float,   // intensidad del estilo (denoise)
    val control: Float     // fidelidad al contorno/pose de la foto
)

val TEMPLATES = listOf(
    Template(
        "comic_color", "Cómic color", "Trazo grueso, colores vivos",
        Color(0xFFE53935), Color(0xFFFFB300),
        "comic illustration, bold ink outlines, vibrant colors, cel shading, detailed, same person, same clothes, same background",
        0.55f, 0.8f
    ),
    Template(
        "comic_suave", "Cómic suave", "Contorno fino, tonos cálidos",
        Color(0xFF00897B), Color(0xFF80CBC4),
        "soft comic illustration, thin ink lines, warm colors, gentle cel shading, same person, same background",
        0.45f, 0.9f
    ),
    Template(
        "pop_art", "Pop art", "Colores planos y contraste alto",
        Color(0xFF8E24AA), Color(0xFFFF4081),
        "pop art illustration, flat bold colors, high contrast, thick outlines, halftone, same person",
        0.65f, 0.7f
    )
)
