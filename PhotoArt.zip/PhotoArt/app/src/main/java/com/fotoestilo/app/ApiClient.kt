package com.fotoestilo.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

object ApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .build()

    fun stylize(
        baseUrl: String, apiKey: String, jpeg: ByteArray, t: Template,
        strength: Float, control: Float, seed: Long
    ): Bitmap {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("prompt", t.prompt)
            .addFormDataPart("strength", strength.toString())
            .addFormDataPart("control", control.toString())
            .addFormDataPart("seed", seed.toString())
            .addFormDataPart("image", "foto.jpg", jpeg.toRequestBody("image/jpeg".toMediaType()))
            .build()
        val req = Request.Builder()
            .url(baseUrl.trim().trimEnd('/') + "/stylize")
            .header("x-api-key", apiKey)
            .post(body)
            .build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Servidor respondió ${r.code}: ${r.body?.string()?.take(200)}")
            val bytes = r.body!!.bytes()
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: error("Respuesta no es una imagen")
        }
    }

    fun upscale(baseUrl: String, apiKey: String, jpeg: ByteArray, scale: Int): Bitmap {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("scale", scale.toString())
            .addFormDataPart("image", "foto.jpg", jpeg.toRequestBody("image/jpeg".toMediaType()))
            .build()
        val req = Request.Builder()
            .url(baseUrl.trim().trimEnd('/') + "/upscale")
            .header("x-api-key", apiKey)
            .post(body)
            .build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) error("Servidor respondió ${r.code}: ${r.body?.string()?.take(200)}")
            val bytes = r.body!!.bytes()
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: error("Respuesta no es una imagen")
        }
    }
}
