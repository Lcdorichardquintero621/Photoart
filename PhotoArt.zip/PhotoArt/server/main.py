"""Servidor de estilizado: SDXL img2img + ControlNet canny (+ LoRA opcional).
Requiere GPU NVIDIA (>= 12 GB VRAM recomendado).

Uso:
  pip install -r requirements.txt
  API_KEY=tu_clave LORA_PATH=/ruta/comic.safetensors uvicorn main:app --host 0.0.0.0 --port 8000
"""
import io
import os

import cv2
import numpy as np
import torch
from diffusers import AutoencoderKL, ControlNetModel, StableDiffusionXLControlNetImg2ImgPipeline
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import Response
from PIL import Image

API_KEY = os.getenv("API_KEY", "")
LORA_PATH = os.getenv("LORA_PATH", "")
DEV = "cuda"

controlnet = ControlNetModel.from_pretrained(
    "diffusers/controlnet-canny-sdxl-1.0", torch_dtype=torch.float16
)
vae = AutoencoderKL.from_pretrained("madebyollin/sdxl-vae-fp16-fix", torch_dtype=torch.float16)
pipe = StableDiffusionXLControlNetImg2ImgPipeline.from_pretrained(
    "stabilityai/stable-diffusion-xl-base-1.0",
    controlnet=controlnet, vae=vae, torch_dtype=torch.float16,
).to(DEV)
if LORA_PATH:
    pipe.load_lora_weights(LORA_PATH)

NEGATIVE = "photo, realistic, blurry, low quality, deformed face, extra fingers, text errors"
app = FastAPI()


@app.post("/stylize")
async def stylize(
    image: UploadFile = File(...),
    prompt: str = Form(...),
    strength: float = Form(0.55),
    control: float = Form(0.8),
    seed: int = Form(42),
    x_api_key: str = Header(default=""),
):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="API key inválida")

    img = Image.open(io.BytesIO(await image.read())).convert("RGB")
    scale = 1024 / max(img.size)
    if scale < 1:
        img = img.resize((int(img.width * scale), int(img.height * scale)))
    w, h = img.width // 8 * 8, img.height // 8 * 8
    img = img.resize((w, h))

    edges = cv2.Canny(np.array(img), 100, 200)
    control_img = Image.fromarray(np.stack([edges] * 3, axis=-1))

    out = pipe(
        prompt=prompt,
        negative_prompt=NEGATIVE,
        image=img,
        control_image=control_img,
        strength=float(strength),
        controlnet_conditioning_scale=float(control),
        num_inference_steps=30,
        guidance_scale=7.0,
        generator=torch.Generator(DEV).manual_seed(int(seed)),
    ).images[0]

    buf = io.BytesIO()
    out.save(buf, format="PNG")
    return Response(content=buf.getvalue(), media_type="image/png")


# ---------------------------------------------------------------------------
# Mejorar calidad y ampliar (Real-ESRGAN x4plus)
# ---------------------------------------------------------------------------
ESRGAN_PATH = os.getenv(
    "ESRGAN_PATH",
    "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth",
)
MAX_SIDE_OUT = 4096
_upscaler = None


def get_upscaler():
    global _upscaler
    if _upscaler is None:
        from basicsr.archs.rrdbnet_arch import RRDBNet
        from realesrgan import RealESRGANer

        model = RRDBNet(num_in_ch=3, num_out_ch=3, num_feat=64, num_block=23, num_grow_ch=32, scale=4)
        _upscaler = RealESRGANer(
            scale=4, model_path=ESRGAN_PATH, model=model,
            tile=400, tile_pad=10, pre_pad=0, half=True,
        )
    return _upscaler


@app.post("/upscale")
async def upscale(
    image: UploadFile = File(...),
    scale: int = Form(2),
    x_api_key: str = Header(default=""),
):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="API key inválida")

    img = Image.open(io.BytesIO(await image.read())).convert("RGB")
    bgr = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

    # no pasar de 4096 px por lado para que el teléfono pueda mostrarla
    outscale = min(float(scale), MAX_SIDE_OUT / max(img.size))
    if outscale < 1.0:
        raise HTTPException(status_code=400, detail="La imagen ya es muy grande")

    out_bgr, _ = get_upscaler().enhance(bgr, outscale=outscale)
    out = Image.fromarray(cv2.cvtColor(out_bgr, cv2.COLOR_BGR2RGB))

    buf = io.BytesIO()
    out.save(buf, format="PNG")
    return Response(content=buf.getvalue(), media_type="image/png")
